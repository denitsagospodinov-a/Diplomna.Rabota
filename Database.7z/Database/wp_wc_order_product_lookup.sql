-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 12, 2024 at 05:42 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inkandquill`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_order_product_lookup`
--

CREATE TABLE `wp_wc_order_product_lookup` (
  `order_item_id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `variation_id` bigint(20) UNSIGNED NOT NULL,
  `customer_id` bigint(20) UNSIGNED DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `product_qty` int(11) NOT NULL,
  `product_net_revenue` double NOT NULL DEFAULT 0,
  `product_gross_revenue` double NOT NULL DEFAULT 0,
  `coupon_amount` double NOT NULL DEFAULT 0,
  `tax_amount` double NOT NULL DEFAULT 0,
  `shipping_amount` double NOT NULL DEFAULT 0,
  `shipping_tax_amount` double NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_wc_order_product_lookup`
--

INSERT INTO `wp_wc_order_product_lookup` (`order_item_id`, `order_id`, `product_id`, `variation_id`, `customer_id`, `date_created`, `product_qty`, `product_net_revenue`, `product_gross_revenue`, `coupon_amount`, `tax_amount`, `shipping_amount`, `shipping_tax_amount`) VALUES
(11, 302, 115, 0, 2, '2024-06-01 12:57:25', 1, 16.9, 21.8, 0, 0, 4.9, 0),
(22, 303, 196, 0, 5, '2024-06-01 13:12:17', 1, 17, 17, 0, 0, 0, 0),
(23, 303, 194, 0, 5, '2024-06-01 13:12:17', 1, 24.99, 24.99, 0, 0, 0, 0),
(32, 304, 189, 0, 3, '2024-06-01 13:18:32', 1, 12, 14.45, 0, 0, 2.45, 0),
(33, 304, 133, 0, 3, '2024-06-01 13:18:32', 1, 7.99, 10.44, 0, 0, 2.45, 0),
(42, 305, 160, 0, 4, '2024-06-01 13:23:37', 1, 24.9, 27.35, 0, 0, 2.45, 0),
(43, 305, 206, 0, 4, '2024-06-01 13:23:37', 1, 17.95, 20.4, 0, 0, 2.45, 0),
(53, 306, 153, 0, 6, '2024-06-01 13:28:58', 1, 19.9, 19.9, 0, 0, 0, 0),
(54, 306, 166, 0, 6, '2024-06-01 13:28:58', 1, 19.9, 19.9, 0, 0, 0, 0),
(55, 306, 199, 0, 6, '2024-06-01 13:28:58', 1, 24, 24, 0, 0, 0, 0),
(65, 308, 135, 0, 5, '2024-06-02 16:58:18', 1, 6.9, 8.533333, 0, 0, 1.633333, 0),
(66, 308, 137, 0, 5, '2024-06-02 16:58:18', 1, 6.5, 8.133333, 0, 0, 1.633333, 0),
(67, 308, 100, 0, 5, '2024-06-02 16:58:18', 1, 10.9, 12.533333, 0, 0, 1.633333, 0),
(71, 309, 170, 0, 5, '2024-06-01 16:59:19', 1, 29, 29, 0, 0, 0, 0),
(74, 310, 213, 0, 6, '2024-06-01 17:00:55', 1, 12.9, 14.533333, 0, 0, 1.633333, 0),
(75, 310, 203, 0, 6, '2024-06-01 17:00:55', 1, 18, 19.633333, 0, 0, 1.633333, 0),
(76, 310, 122, 0, 6, '2024-06-01 17:00:55', 1, 19.9, 21.533333, 0, 0, 1.633333, 0),
(80, 311, 111, 0, 3, '2024-06-01 17:07:07', 1, 15.9, 15.9, 0, 0, 0, 0),
(81, 311, 115, 0, 3, '2024-06-01 17:07:07', 1, 16.9, 16.9, 0, 0, 0, 0),
(82, 311, 113, 0, 3, '2024-06-01 17:07:07', 1, 15.9, 15.9, 0, 0, 0, 0),
(83, 311, 118, 0, 3, '2024-06-01 17:07:07', 1, 16.9, 16.9, 0, 0, 0, 0),
(87, 312, 156, 0, 4, '2024-06-01 17:09:00', 1, 12.9, 14.125, 0, 0, 1.225, 0),
(88, 312, 158, 0, 4, '2024-06-01 17:09:00', 1, 12.9, 14.125, 0, 0, 1.225, 0),
(89, 312, 141, 0, 4, '2024-06-01 17:09:00', 1, 17.9, 19.125, 0, 0, 1.225, 0),
(90, 312, 151, 0, 4, '2024-06-01 17:09:00', 1, 14.9, 16.125, 0, 0, 1.225, 0),
(106, 336, 211, 0, 8, '2024-07-17 12:27:52', 1, 20, 24.9, 0, 0, 4.9, 0),
(122, 365, 166, 0, 10, '2024-08-11 14:02:45', 1, 19.9, 24.8, 0, 0, 4.9, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_wc_order_product_lookup`
--
ALTER TABLE `wp_wc_order_product_lookup`
  ADD PRIMARY KEY (`order_item_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `date_created` (`date_created`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
