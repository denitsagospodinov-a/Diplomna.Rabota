-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 12, 2024 at 05:42 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inkandquill`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_order_addresses`
--

CREATE TABLE `wp_wc_order_addresses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `address_type` varchar(20) DEFAULT NULL,
  `first_name` text DEFAULT NULL,
  `last_name` text DEFAULT NULL,
  `address_1` text DEFAULT NULL,
  `city` text DEFAULT NULL,
  `state` text DEFAULT NULL,
  `postcode` text DEFAULT NULL,
  `country` text DEFAULT NULL,
  `email` varchar(320) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `company` text DEFAULT NULL,
  `address_2` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_wc_order_addresses`
--

INSERT INTO `wp_wc_order_addresses` (`id`, `order_id`, `address_type`, `first_name`, `last_name`, `address_1`, `city`, `state`, `postcode`, `country`, `email`, `phone`, `company`, `address_2`) VALUES
(3, 302, 'billing', 'Петя', 'Стефанова', 'ул. \"Иван Вазов\", №53', 'София', 'BG-22', '1000', 'BG', 'petya65@gmail.com', '0884792019', NULL, NULL),
(4, 302, 'shipping', 'Петя', 'Стефанова', 'ул. \"Иван Вазов\", №53', 'София', 'BG-22', '1000', 'BG', NULL, '0884792019', NULL, NULL),
(21, 303, 'billing', 'Димитър', 'Петров', 'ул. \"Христо Ботев\", №17', 'Пловдив', 'BG-16', '4000', 'BG', 'dimitarP365@gmail.com', '0889561392', NULL, NULL),
(22, 303, 'shipping', 'Димитър', 'Петров', 'ул. \"Христо Ботев\", №17', 'Пловдив', 'BG-16', '4000', 'BG', NULL, '0889561392', NULL, NULL),
(35, 304, 'billing', 'Стефания', 'Колева', 'ул. \"Берое\", №5', 'Стара Загора', 'BG-24', '6000', 'BG', 'stefik13@gmail.com', '0889762450', NULL, NULL),
(36, 304, 'shipping', 'Стефания', 'Колева', 'ул. \"Берое\", №5', 'Стара Загора', 'BG-24', '6000', 'BG', NULL, '0889762450', NULL, NULL),
(49, 305, 'billing', 'Мария', 'Недева', 'ул. \"Васил Левски\", №43', 'Бургас', 'BG-02', '8000', 'BG', 'mariaN71@gmail.com', '0887459218', NULL, NULL),
(50, 305, 'shipping', 'Мария', 'Недева', 'ул. \"Васил Левски\", №43', 'Бургас', 'BG-02', '8000', 'BG', NULL, '0887459218', NULL, NULL),
(65, 306, 'billing', 'Иван', 'Георгиев', 'ул. \"Цар Иван Шишман\", №81', 'Велико Търново', 'BG-04', '5000', 'BG', 'ivan.g@gmail.com', '0883912025', NULL, NULL),
(66, 306, 'shipping', 'Иван', 'Георгиев', 'ул. \"Цар Иван Шишман\", №81', 'Велико Търново', 'BG-04', '5000', 'BG', NULL, '0883912025', NULL, NULL),
(81, 308, 'billing', 'Димитър', 'Петров', 'ул. “Христо Ботев”, №17', 'Пловдив', 'BG-16', '4000', 'BG', 'dimitarP365@gmail.com', '0889561392', NULL, NULL),
(82, 308, 'shipping', 'Димитър', 'Петров', 'ул. “Христо Ботев”, №17', 'Пловдив', 'BG-16', '4000', 'BG', NULL, '0889561392', NULL, NULL),
(85, 309, 'billing', 'Димитър', 'Петров', 'ул. “Христо Ботев”, №17', 'Пловдив', 'BG-16', '4000', 'BG', 'dimitarP365@gmail.com', '0889561392', NULL, NULL),
(86, 309, 'shipping', 'Димитър', 'Петров', 'ул. “Христо Ботев”, №17', 'Пловдив', 'BG-16', '4000', 'BG', NULL, '0889561392', NULL, NULL),
(87, 310, 'billing', 'Иван', 'Георгиев', 'ул. “Цар Иван Шишман”, №81', 'Велико Търново', 'BG-04', '5000', 'BG', 'ivan.g@gmail.com', '0883912025', NULL, NULL),
(88, 310, 'shipping', 'Иван', 'Георгиев', 'ул. “Цар Иван Шишман”, №81', 'Велико Търново', 'BG-04', '5000', 'BG', NULL, '0883912025', NULL, NULL),
(91, 311, 'billing', 'Стефания', 'Колева', 'ул. “Берое”, №5', 'Стара Загора', 'BG-24', '6000', 'BG', 'stefik13@gmail.com', '0889762450', NULL, NULL),
(92, 311, 'shipping', 'Стефания', 'Колева', 'ул. “Берое”, №5', 'Стара Загора', 'BG-24', '6000', 'BG', NULL, '0889762450', NULL, NULL),
(95, 312, 'billing', 'Мария', 'Недева', 'ул. “Васил Левски”, №43', 'Бургас', 'BG-02', '8000', 'BG', 'mariaN71@gmail.com', '0887459218', NULL, NULL),
(96, 312, 'shipping', 'Мария', 'Недева', 'ул. “Васил Левски”, №43', 'Бургас', 'BG-02', '8000', 'BG', NULL, '0887459218', NULL, NULL),
(99, 332, 'billing', NULL, NULL, NULL, NULL, 'BG-22', NULL, 'BG', NULL, NULL, NULL, NULL),
(100, 332, 'shipping', NULL, NULL, NULL, NULL, 'BG-22', NULL, 'BG', NULL, NULL, NULL, NULL),
(101, 333, 'billing', NULL, NULL, NULL, NULL, 'BG-22', NULL, 'BG', 'denitsa0907@mail.bg', NULL, NULL, NULL),
(102, 333, 'shipping', NULL, NULL, NULL, NULL, 'BG-22', NULL, 'BG', NULL, NULL, NULL, NULL),
(103, 334, 'billing', NULL, NULL, NULL, NULL, 'BG-22', NULL, 'BG', 'denitsa0907@mail.bg', NULL, NULL, NULL),
(104, 334, 'shipping', NULL, NULL, NULL, NULL, 'BG-22', NULL, 'BG', NULL, NULL, NULL, NULL),
(105, 335, 'billing', NULL, NULL, NULL, NULL, 'BG-22', NULL, 'BG', 'denitsa0907@mail.bg', NULL, NULL, NULL),
(106, 335, 'shipping', NULL, NULL, NULL, NULL, 'BG-22', NULL, 'BG', NULL, NULL, NULL, NULL),
(107, 336, 'billing', 'Деница', 'Господинова', 'пл. \"Берое\", № 5', 'Стара Загора', 'BG-24', '6000', 'BG', 'denitsa0907@mail.bg', NULL, NULL, NULL),
(108, 336, 'shipping', 'Деница', 'Господинова', 'пл. \"Берое\", № 5', 'Стара Загора', 'BG-24', '6000', 'BG', NULL, NULL, NULL, NULL),
(113, 365, 'billing', 'Деница', 'Господинова', 'пл. \"Берое\" 5, Стара Загора, България', 'Стара Загора', 'BG-24', '6000', 'BG', 'denitsa0901@gmail.com', '0882704504', NULL, NULL),
(114, 365, 'shipping', 'Деница', 'Господинова', 'пл. \"Берое\" 5, Стара Загора, България', 'Стара Загора', 'BG-24', '6000', 'BG', NULL, '0882704504', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_wc_order_addresses`
--
ALTER TABLE `wp_wc_order_addresses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `address_type_order_id` (`address_type`,`order_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `email` (`email`(191)),
  ADD KEY `phone` (`phone`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wp_wc_order_addresses`
--
ALTER TABLE `wp_wc_order_addresses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=115;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
