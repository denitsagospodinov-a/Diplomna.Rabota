-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 11, 2024 at 01:21 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inkandquill`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_order_stats`
--

CREATE TABLE `wp_wc_order_stats` (
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `parent_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_paid` datetime DEFAULT '0000-00-00 00:00:00',
  `date_completed` datetime DEFAULT '0000-00-00 00:00:00',
  `num_items_sold` int(11) NOT NULL DEFAULT 0,
  `total_sales` double NOT NULL DEFAULT 0,
  `tax_total` double NOT NULL DEFAULT 0,
  `shipping_total` double NOT NULL DEFAULT 0,
  `net_total` double NOT NULL DEFAULT 0,
  `returning_customer` tinyint(1) DEFAULT NULL,
  `status` varchar(200) NOT NULL,
  `customer_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_wc_order_stats`
--

INSERT INTO `wp_wc_order_stats` (`order_id`, `parent_id`, `date_created`, `date_created_gmt`, `date_paid`, `date_completed`, `num_items_sold`, `total_sales`, `tax_total`, `shipping_total`, `net_total`, `returning_customer`, `status`, `customer_id`) VALUES
(302, 0, '2024-06-01 12:57:25', '2024-06-01 09:57:25', '2024-06-01 17:02:52', '2024-06-01 17:02:52', 1, 21.8, 0, 4.9, 16.9, 0, 'wc-completed', 2),
(303, 0, '2024-06-01 13:12:17', '2024-06-01 10:12:17', NULL, NULL, 2, 41.99, 0, 0, 41.99, 0, 'wc-processing', 5),
(304, 0, '2024-06-01 13:18:32', '2024-06-01 10:18:32', '2024-06-01 17:04:23', '2024-06-01 18:10:23', 2, 24.89, 0, 4.9, 19.99, 0, 'wc-completed', 3),
(305, 0, '2024-06-01 13:23:37', '2024-06-01 10:23:37', '2024-06-01 18:10:57', '2024-06-01 18:10:57', 2, 47.75, 0, 4.9, 42.85, 0, 'wc-completed', 4),
(306, 0, '2024-06-01 13:28:58', '2024-06-01 10:28:58', NULL, NULL, 3, 63.8, 0, 0, 63.8, 0, 'wc-processing', 6),
(308, 0, '2024-06-02 16:58:18', '2024-06-02 13:58:18', '2024-06-01 18:12:21', '2024-06-01 18:12:21', 3, 29.2, 0, 4.9, 24.3, 1, 'wc-completed', 5),
(309, 0, '2024-06-01 16:59:19', '2024-06-01 13:59:19', NULL, NULL, 1, 29, 0, 0, 29, 1, 'wc-cancelled', 5),
(310, 0, '2024-06-01 17:00:55', '2024-06-01 14:00:55', NULL, NULL, 3, 55.7, 0, 4.9, 50.8, 1, 'wc-processing', 6),
(311, 0, '2024-06-01 17:07:07', '2024-06-01 14:07:07', NULL, NULL, 4, 65.6, 0, 0, 65.6, 1, 'wc-on-hold', 3),
(312, 0, '2024-06-01 17:09:00', '2024-06-01 14:09:00', NULL, NULL, 4, 63.5, 0, 4.9, 58.6, 1, 'wc-processing', 4),
(336, 0, '2024-07-17 12:27:52', '2024-07-17 09:27:52', NULL, NULL, 1, 24.9, 0, 4.9, 20, 0, 'wc-on-hold', 8),
(365, 0, '2024-08-11 14:02:45', '2024-08-11 11:02:45', NULL, NULL, 1, 24.8, 0, 4.9, 19.9, 0, 'wc-on-hold', 10);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_wc_order_stats`
--
ALTER TABLE `wp_wc_order_stats`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `date_created` (`date_created`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `status` (`status`(191));
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
