-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 12, 2024 at 05:42 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inkandquill`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_product_meta_lookup`
--

CREATE TABLE `wp_wc_product_meta_lookup` (
  `product_id` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` decimal(19,4) DEFAULT NULL,
  `stock_quantity` double DEFAULT NULL,
  `stock_status` varchar(100) DEFAULT 'instock',
  `total_sales` bigint(20) DEFAULT 0,
  `tax_status` varchar(100) DEFAULT 'taxable',
  `sku` varchar(100) DEFAULT '',
  `virtual` tinyint(1) DEFAULT 0,
  `downloadable` tinyint(1) DEFAULT 0,
  `min_price` decimal(19,4) DEFAULT NULL,
  `max_price` decimal(19,4) DEFAULT NULL,
  `onsale` tinyint(1) DEFAULT 0,
  `rating_count` bigint(20) DEFAULT 0,
  `average_rating` decimal(3,2) DEFAULT 0.00,
  `tax_class` varchar(100) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_wc_product_meta_lookup`
--

INSERT INTO `wp_wc_product_meta_lookup` (`product_id`, `name`, `price`, `stock_quantity`, `stock_status`, `total_sales`, `tax_status`, `sku`, `virtual`, `downloadable`, `min_price`, `max_price`, `onsale`, `rating_count`, `average_rating`, `tax_class`) VALUES
(166, '', NULL, NULL, 'instock', 2, 'taxable', '', 0, 0, 19.9000, 19.9000, 0, 0, 0.00, ''),
(211, '', NULL, NULL, 'instock', 1, 'taxable', '', 0, 0, 20.0000, 20.0000, 0, 0, 0.00, ''),
(137, 'Тайната градина', 6.5000, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(129, 'Приключенията на Том Сойер', 6.9000, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(135, 'Приключенията на Пинокио', 6.9000, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(133, 'Патиланско царство', 7.9900, NULL, 'instock', 1, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(131, 'Роня, дъщерята на разбойника ', 8.9000, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(100, 'Пипи Дългото чорапче', 10.9000, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(189, 'Цветя в стаята', 12.0000, NULL, 'instock', 1, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(156, 'Пърси Джаксън и боговете на Олимп – Похитителят на мълнии – книга 1', 12.9000, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(158, 'Пърси Джаксън и боговете на Олимп – Морето на чудовищата – книга 2', 12.9000, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(213, 'Изкуството да убеждаваш', 12.9000, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(177, 'Математика – матура без проблеми', 14.0000, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(151, 'Елизабет и тронът на Медния град', 14.9000, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(164, 'Дъщеря на дълбините', 14.9000, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(168, 'Изпитанията на Аполон: Скритият оракул – Книга 1', 14.9000, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(111, 'Бриджъртън – Херцогът и аз – книга 1', 15.9000, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(113, 'Бриджъртън – Виконтът, който ме обикна – книга 2', 15.9000, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(127, 'Приключенията на Лукчо', 15.9000, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(147, 'Десет истини и едно предизвикателство', 15.9000, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(149, 'Всички феи на кралството', 16.0000, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(115, 'Бриджъртън – Предложение от джентълмен – книга 3', 16.9000, NULL, 'instock', 1, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(118, 'Да флиртуваш с Бриджъртън – книга 4', 16.9000, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(196, '50-те най-велики български спортисти, чийто постижения ни правят горди българи', 17.0000, NULL, 'instock', 1, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(141, 'Дневникът на вещицата по неволя', 17.9000, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(206, 'Устойчиви на стрес', 17.9500, NULL, 'instock', 1, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(181, 'Климатология', 18.0000, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(203, 'Силата на самоконтрола – Дисциплината е съдба', 18.0000, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(208, 'Въведение във философията', 18.0000, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(143, 'Какво би направила Уензди?', 18.5000, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(122, 'Господар на гнева', 19.9000, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(153, 'Щипка магия', 19.9000, NULL, 'instock', 1, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(187, 'Първа помощ за детето', 19.9900, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(124, 'Империя на греха', 20.0000, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(183, 'Черни дупки и бебета вселени и други есета', 21.9900, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(120, 'Шах и Мат', 22.0000, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(218, 'Без съмнение – Култура и ценност – Лекция върху етиката', 22.0000, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(145, 'Слънчеви лъчи в мрака', 22.9000, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(174, 'Изкуството на разузнаването', 23.0000, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(199, 'Какво искат кучетата', 24.0000, NULL, 'instock', 1, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(160, 'Героите на Олимп – Изчезналият герой – книга 1', 24.9000, NULL, 'instock', 1, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(162, 'Героите на Олимп – Синът на Нептун – книга 2', 24.9000, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(185, '100+ рецепти за италиански десерти и сладкиши', 24.9500, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(194, 'Формула 1 – В бокса и извън него', 24.9900, NULL, 'instock', 1, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(172, 'Латински език с медицинска терминология', 25.0000, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(216, 'Чувствам, следователно съм', 25.0000, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(170, 'Adobe After Effects CC 2015', 29.0000, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(179, 'Химия на елементите и техните съединения', 35.0000, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, ''),
(191, 'Основи на подводния риболов', 55.0000, NULL, 'instock', 0, 'taxable', '', 0, 0, NULL, NULL, 0, 0, 0.00, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_wc_product_meta_lookup`
--
ALTER TABLE `wp_wc_product_meta_lookup`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `stock_status` (`stock_status`),
  ADD KEY `stock_quantity` (`stock_quantity`),
  ADD KEY `min_max_price` (`price`),
  ADD KEY `virtual` (`virtual`),
  ADD KEY `downloadable` (`downloadable`),
  ADD KEY `onsale` (`onsale`),
  ADD KEY `sku` (`sku`(50));
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
