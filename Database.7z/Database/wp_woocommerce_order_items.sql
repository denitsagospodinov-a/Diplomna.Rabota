-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 12, 2024 at 05:41 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inkandquill`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_order_items`
--

CREATE TABLE `wp_woocommerce_order_items` (
  `order_item_id` bigint(20) UNSIGNED NOT NULL,
  `order_item_name` text NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `order_item_type` varchar(200) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_woocommerce_order_items`
--

INSERT INTO `wp_woocommerce_order_items` (`order_item_id`, `order_item_name`, `order_id`, `order_item_type`) VALUES
(11, 'Бриджъртън - Предложение от джентълмен - книга 3', 302, ''),
(22, '50-те най-велики български спортисти, чийто постижения ни правят горди българи', 303, ''),
(23, 'Формула 1 - В бокса и извън него', 303, ''),
(32, 'Цветя в стаята', 304, ''),
(33, 'Патиланско царство', 304, ''),
(42, 'Героите на Олимп - Изчезналият герой - книга 1', 305, ''),
(43, 'Устойчиви на стрес', 305, ''),
(53, 'Щипка магия', 306, ''),
(54, 'Хрониките на Кейн - Червената пирамида', 306, ''),
(55, 'Какво искат кучетата', 306, ''),
(65, 'Приключенията на Пинокио', 308, ''),
(66, 'Тайната градина', 308, ''),
(67, 'Пипи Дългото чорапче', 308, ''),
(71, 'Adobe After Effects CC 2015', 309, ''),
(74, 'Изкуството да убеждаваш', 310, ''),
(75, 'Силата на самоконтрола - Дисциплината е съдба', 310, ''),
(76, 'Господар на гнева', 310, ''),
(80, 'Бриджъртън - Херцогът и аз - книга 1', 311, ''),
(81, 'Бриджъртън - Предложение от джентълмен - книга 3', 311, ''),
(82, 'Бриджъртън - Виконтът, който ме обикна - книга 2', 311, ''),
(83, 'Да флиртуваш с Бриджъртън - книга 4', 311, ''),
(86, 'Вземане от място (Книжарница \"INK &amp; QUILL\")', 311, ''),
(87, 'Пърси Джаксън и боговете на Олимп - Похитителят на мълнии - книга 1', 312, ''),
(88, 'Пърси Джаксън и боговете на Олимп - Морето на чудовищата - книга 2', 312, ''),
(89, 'Дневникът на вещицата по неволя', 312, ''),
(90, 'Елизабет и тронът на Медния град', 312, ''),
(93, 'Flat rate', 312, ''),
(106, 'Силата на мозъка', 336, 'line_item'),
(113, 'Flat rate', 336, 'shipping'),
(122, 'Хрониките на Кейн - Червената пирамида', 365, 'line_item'),
(132, 'Flat rate', 365, 'shipping');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_woocommerce_order_items`
--
ALTER TABLE `wp_woocommerce_order_items`
  ADD PRIMARY KEY (`order_item_id`),
  ADD KEY `order_id` (`order_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wp_woocommerce_order_items`
--
ALTER TABLE `wp_woocommerce_order_items`
  MODIFY `order_item_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=133;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
