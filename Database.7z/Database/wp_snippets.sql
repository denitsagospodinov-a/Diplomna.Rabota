-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 02, 2024 at 11:09 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inkandquill`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_snippets`
--

CREATE TABLE `wp_snippets` (
  `id` bigint(20) NOT NULL,
  `name` tinytext NOT NULL,
  `description` text NOT NULL,
  `code` longtext NOT NULL,
  `tags` longtext NOT NULL,
  `scope` varchar(15) NOT NULL DEFAULT 'global',
  `priority` smallint(6) NOT NULL DEFAULT 10,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `modified` datetime NOT NULL DEFAULT current_timestamp(),
  `revision` bigint(20) NOT NULL DEFAULT 1,
  `cloud_id` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_snippets`
--

INSERT INTO `wp_snippets` (`id`, `name`, `description`, `code`, `tags`, `scope`, `priority`, `active`, `modified`, `revision`, `cloud_id`) VALUES
(1, 'Make upload filenames lowercase', 'Makes sure that image and file uploads have lowercase filenames.\n\nThis is a sample snippet. Feel free to use it, edit it, or remove it.', 'add_filter( \'sanitize_file_name\', \'mb_strtolower\' );', 'sample, media', 'global', 10, 0, '2024-05-26 09:54:07', 2, NULL),
(2, 'Disable admin bar', 'Turns off the WordPress admin bar for everyone except administrators.\n\nThis is a sample snippet. Feel free to use it, edit it, or remove it.', 'add_action( \'wp\', function () {\n	if ( ! current_user_can( \'manage_options\' ) ) {\n		show_admin_bar( false );\n	}\n} );', 'sample, admin-bar', 'front-end', 10, 0, '2024-05-26 09:54:07', 2, NULL),
(3, 'Allow smilies', 'Allows smiley conversion in obscure places.\n\nThis is a sample snippet. Feel free to use it, edit it, or remove it.', 'add_filter( \'widget_text\', \'convert_smilies\' );\nadd_filter( \'the_title\', \'convert_smilies\' );\nadd_filter( \'wp_title\', \'convert_smilies\' );\nadd_filter( \'get_bloginfo\', \'convert_smilies\' );', 'sample', 'global', 10, 0, '2024-05-26 09:54:07', 2, NULL),
(4, 'Current year', 'Shortcode for inserting the current year into a post or page..\n\nThis is a sample snippet. Feel free to use it, edit it, or remove it.', '<?php echo date( \'Y\' ); ?>', 'sample, dates', 'content', 10, 0, '2024-05-26 09:54:07', 2, NULL),
(5, 'Book Info', '', 'add_action(\'woocommerce_before_add_to_cart_form\', \'book_info\');\nfunction book_info() { \n    if ( $book_author = get_field( \'book_author\' ) ) : ?>\n        <p>Автор: <?php echo esc_html( $book_author ); ?></p>\n    <?php endif; }\n', '', 'global', 10, 1, '2024-07-16 08:49:04', 13, NULL),
(6, 'Book Publisher', '', 'add_action(\'woocommerce_before_add_to_cart_form\', \'book_publisher\'); \nfunction book_publisher() \n{ \n    if ( $book_publisher = get_field( \'book_publisher\' ) ) : ?> \n        <p>Издателство: <?php echo esc_html( $book_publisher ); ?></p> \n    <?php endif; } \n', '', 'global', 10, 1, '2024-07-19 12:29:20', 5, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_snippets`
--
ALTER TABLE `wp_snippets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `scope` (`scope`),
  ADD KEY `active` (`active`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wp_snippets`
--
ALTER TABLE `wp_snippets`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
