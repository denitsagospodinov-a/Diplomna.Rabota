-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 12, 2024 at 05:43 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inkandquill`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_users`
--

CREATE TABLE `wp_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(255) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT 0,
  `display_name` varchar(250) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(5, 'MariN27', '$P$ByGGrvwyjXYSiIXu7MClT3hpfDhCRU1', 'marin27', 'mariaN71@gmail.com', '', '2024-06-01 09:50:34', '1717235435:$P$BM0IP7EZo5x9x45H91X.8VoqlCuVDk/', 0, 'Maria Nedeva'),
(7, 'lora123', '$P$BR2bsGgk7ZGue8EeZ0saJMeQq5VI2p0', 'lora123', 'lora183@gmail.com', '', '2024-06-02 10:21:21', '', 0, 'Lora Antonova'),
(8, 'denitsa09', '$P$BQp5CfiRjcOdZgvDqFvaUcgYuHxJkS.', 'denitsa09', 'denitsa0901@gmail.com', '', '2024-08-11 09:35:27', '', 0, 'Denitsa Gospodinova'),
(2, 'ivan.g', '$P$BQDvRR2eZwX9o1ekwECr1fexXhmYO6.', 'ivan-g', 'ivan.g@gmail.com', '', '2024-06-01 09:43:11', '', 0, 'Ivan Georgiev'),
(4, 'Stefi.I7', '$P$BnK714DUdZN7kZdj0Dc/Ub1744Iy3m1', 'stefi-i7', 'stefik13@gmail.com', '', '2024-06-01 09:48:20', '1717235301:$P$BxlJTVnvN8ezBdRjaRM2VI971WhmwZ.', 0, 'Stefania Koleva'),
(6, 'dimitarP3', '$P$BI7H7mNgC6WWbtKO97oSM45BCPXBGG.', 'dimitarp3', 'dimitarP365@gmail.com', '', '2024-06-01 09:54:39', '1717235679:$P$BpQJuiU6NB.3Dhb3K8rggv76Os4b3L1', 0, 'Dimitar Petrov'),
(1, 'root', '$P$BeQ4R44ufbAjoO/LZj6cgsmopOEyg51', 'root', 'denitsa0907@mail.bg', 'http://localhost/inkandquill', '2024-05-12 13:22:58', '', 0, 'root'),
(3, 'petyaS', '$P$BA8qi6RmkLdGz7C3ae5asX48I2lsXL1', 'petyas', 'petya65@gmail.com', '', '2024-06-01 09:46:25', '1717235185:$P$BwxT/k/OXigE4ksLPRaIGACjZDM8Dt0', 0, 'Petya Stefanova');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_users`
--
ALTER TABLE `wp_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wp_users`
--
ALTER TABLE `wp_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
