-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 12, 2024 at 05:42 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inkandquill`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_orders`
--

CREATE TABLE `wp_wc_orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `status` varchar(20) DEFAULT NULL,
  `currency` varchar(10) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `total_amount` decimal(26,8) DEFAULT NULL,
  `customer_id` bigint(20) UNSIGNED DEFAULT NULL,
  `billing_email` varchar(320) DEFAULT NULL,
  `date_created_gmt` datetime DEFAULT NULL,
  `date_updated_gmt` datetime DEFAULT NULL,
  `payment_method` varchar(100) DEFAULT NULL,
  `payment_method_title` text DEFAULT NULL,
  `customer_note` text DEFAULT NULL,
  `tax_amount` decimal(26,8) DEFAULT NULL,
  `parent_order_id` bigint(20) UNSIGNED DEFAULT NULL,
  `transaction_id` varchar(100) DEFAULT NULL,
  `ip_address` varchar(100) DEFAULT NULL,
  `user_agent` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_wc_orders`
--

INSERT INTO `wp_wc_orders` (`id`, `status`, `currency`, `type`, `total_amount`, `customer_id`, `billing_email`, `date_created_gmt`, `date_updated_gmt`, `payment_method`, `payment_method_title`, `customer_note`, `tax_amount`, `parent_order_id`, `transaction_id`, `ip_address`, `user_agent`) VALUES
(302, 'wc-completed', 'BGN', 'shop_order', 21.80000000, 3, 'petya65@gmail.com', '2024-06-01 09:57:25', '2024-06-01 14:02:52', 'cod', 'Cash on delivery', '', NULL, NULL, NULL, NULL, NULL),
(303, 'wc-processing', 'BGN', 'shop_order', 41.99000000, 6, 'dimitarP365@gmail.com', '2024-06-01 10:12:17', '2024-06-01 10:14:14', 'cod', 'Cash on delivery', '', NULL, NULL, NULL, NULL, NULL),
(304, 'wc-completed', 'BGN', 'shop_order', 24.89000000, 4, 'stefik13@gmail.com', '2024-06-01 10:18:32', '2024-06-01 15:10:23', 'bacs', 'Direct bank transfer', '', NULL, NULL, NULL, NULL, NULL),
(305, 'wc-completed', 'BGN', 'shop_order', 47.75000000, 5, 'mariaN71@gmail.com', '2024-06-01 10:23:37', '2024-06-01 15:10:57', 'cod', 'Cash on delivery', '', NULL, NULL, NULL, NULL, NULL),
(306, 'wc-processing', 'BGN', 'shop_order', 63.80000000, 2, 'ivan.g@gmail.com', '2024-06-01 10:28:58', '2024-06-01 10:30:37', 'cod', 'Cash on delivery', '', NULL, NULL, NULL, NULL, NULL),
(308, 'wc-completed', 'BGN', 'shop_order', 29.20000000, 6, 'dimitarP365@gmail.com', '2024-06-02 13:58:18', '2024-06-01 15:12:21', 'cod', 'Cash on delivery', '', NULL, NULL, NULL, NULL, NULL),
(309, 'wc-cancelled', 'BGN', 'shop_order', 29.00000000, 6, 'dimitarP365@gmail.com', '2024-06-01 13:59:19', '2024-06-01 15:11:40', 'cod', 'Cash on delivery', '', NULL, NULL, NULL, NULL, NULL),
(310, 'wc-processing', 'BGN', 'shop_order', 55.70000000, 2, 'ivan.g@gmail.com', '2024-06-01 14:00:55', '2024-06-01 14:01:12', 'cod', 'Cash on delivery', '', NULL, NULL, NULL, NULL, NULL),
(311, 'wc-on-hold', 'BGN', 'shop_order', 65.60000000, 4, 'stefik13@gmail.com', '2024-06-01 14:07:07', '2024-06-01 14:07:26', 'bacs', 'Direct bank transfer', '', NULL, NULL, NULL, NULL, NULL),
(312, 'wc-processing', 'BGN', 'shop_order', 63.50000000, 5, 'mariaN71@gmail.com', '2024-06-01 14:09:00', '2024-06-01 14:09:25', 'cod', 'Cash on delivery', '', NULL, NULL, NULL, NULL, NULL),
(332, NULL, NULL, 'shop_order', 20.80000000, NULL, NULL, NULL, '2024-07-16 09:17:07', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(333, NULL, NULL, 'shop_order', 24.90000000, NULL, NULL, NULL, '2024-07-17 09:19:45', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(334, NULL, NULL, 'shop_order', 24.90000000, NULL, NULL, NULL, '2024-07-17 09:20:11', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(335, NULL, NULL, 'shop_order', 24.90000000, NULL, NULL, NULL, '2024-07-17 09:21:26', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(336, 'wc-on-hold', 'BGN', 'shop_order', 24.90000000, 1, 'denitsa0907@mail.bg', '2024-07-17 09:27:52', '2024-07-17 10:17:57', 'bacs', 'Direct bank transfer', '', 0.00000000, 0, '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0'),
(365, 'wc-on-hold', 'BGN', 'shop_order', 24.80000000, 8, 'denitsa0901@gmail.com', '2024-08-11 11:02:45', '2024-08-11 11:14:24', 'bacs', 'Плащане по банков път', '', 0.00000000, 0, '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:129.0) Gecko/20100101 Firefox/129.0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_wc_orders`
--
ALTER TABLE `wp_wc_orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `status` (`status`),
  ADD KEY `date_created` (`date_created_gmt`),
  ADD KEY `customer_id_billing_email` (`customer_id`,`billing_email`(171)),
  ADD KEY `billing_email` (`billing_email`(191)),
  ADD KEY `type_status_date` (`type`,`status`,`date_created_gmt`),
  ADD KEY `date_updated` (`date_updated_gmt`),
  ADD KEY `parent_order_id` (`parent_order_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
