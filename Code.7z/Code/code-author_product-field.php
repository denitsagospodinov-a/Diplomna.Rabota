add_action('woocommerce_before_add_to_cart_form', 'book_info');
function book_info() { 
    if ( $book_author = get_field( 'book_author' ) ) : ?>
        <p>Автор: <?php echo esc_html( $book_author ); ?></p>
    <?php endif; }