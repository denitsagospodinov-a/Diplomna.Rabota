add_action('woocommerce_before_add_to_cart_form', 'book_publisher'); 
function book_publisher() 
{ 
    if ( $book_publisher = get_field( 'book_publisher' ) ) : ?> 
        <p>Издателство: <?php echo esc_html( $book_publisher ); ?></p> 
    <?php endif; } 